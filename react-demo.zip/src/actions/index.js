export const REQUEST_POSTS = 'REQUEST_POSTS'
export const RECEIVE_POSTS = 'RECEIVE_POSTS'
export const SELECT_SUBREDDIT = 'SELECT_SUBREDDIT'
export const INVALIDATE_SUBREDDIT = 'INVALIDATE_SUBREDDIT'
//
// export const selectSubreddit = subreddit => ({
//   type: SELECT_SUBREDDIT,
//   subreddit
// })
//
// export const invalidateSubreddit = subreddit => ({
//   type: INVALIDATE_SUBREDDIT,
//   subreddit
// })
//
// export const requestPosts = subreddit => ({
//   type: REQUEST_POSTS,
//   subreddit
// })
//
// export const receivePosts = (subreddit, json) => ({
//   type: RECEIVE_POSTS,
//   subreddit,
//   posts: json.data.children.map(child => child.data),
//   receivedAt: Date.now()
// })
//
// const fetchPosts = subreddit => dispatch => {
//   dispatch(requestPosts(subreddit))
//   return fetch(`https://www.reddit.com/r/${subreddit}.json`)
//     .then(response => response.json())
//     .then(json => dispatch(receivePosts(subreddit, json)))
// }
//
const shouldFetchPosts = (state, subreddit) => {
  const posts = state.postsBySubreddit[subreddit];
  if (!posts) {
    return true
  }
  if (posts.isFetching) {
    return false
  }
  return posts.didInvalidate
};
//
// export const fetchPostsIfNeeded = subreddit => (dispatch, getState) => {
//   if (shouldFetchPosts(getState(), subreddit)) {
//     return dispatch(fetchPosts(subreddit))
//   }
// }


import dispatchAction from '../redux-dispatch-action';


class Actions {
    constructor() {
        this.$store = null;
    }

    setStore(store) {
        this.$store = store;
    }

    @dispatchAction(SELECT_SUBREDDIT)
    selectSubreddit(subreddit) {
        return {subreddit}
    }

    @dispatchAction(INVALIDATE_SUBREDDIT)
    invalidateSubreddit(subreddit){
        return {subreddit}
    }

    @dispatchAction(REQUEST_POSTS)
    fetchPostsIfNeeded(subreddit){

        var state = this.$store.getState();

        if (!shouldFetchPosts(state, subreddit)) {
            return;
        }

        return new Promise((resolve, reject) => {
            var xxx = this.invalidateSubreddit(subreddit);
            setTimeout(function () {
                resolve({
                    subreddit: subreddit,
                    posts: [{title: subreddit + Math.random()}, {title: subreddit + Math.random()}, {title: subreddit + Math.random()}],
                    receivedAt: Date.now()
                })
            }, 500);
        })
    }


    testFunction(){
        return function () {
            return 23323;
        }
    }
}


export default new Actions();