import React from 'react'
import PropTypes from 'prop-types'
import './Posts.less';

const Posts = ({posts}) => (
  <ul className={'posts'}>
    {posts.map((post, i) =>
      <li key={i}>{post.title}</li>
    )}
  </ul>
)

Posts.propTypes = {
  posts: PropTypes.array.isRequired
}

export default Posts
