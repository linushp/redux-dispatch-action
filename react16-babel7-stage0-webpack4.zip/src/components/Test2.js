import React, {useState} from 'react';
import {connect} from 'react-redux'


function mapStateToProps(state) {
    return {...state}
}


function Test2({selectedSubreddit}) {
    return (
        <div>
            <h1>Test2</h1>
            <div>
                {selectedSubreddit}
            </div>
        </div>
    );
}


export default connect(mapStateToProps)(Test2);