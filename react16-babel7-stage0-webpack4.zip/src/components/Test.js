import React, {useState} from 'react';


export default function () {

    const [count, setCount] = useState(function () {
        return 2323
    });

    const [count1, setCount1] = useState(111);


    function incrementCount() {
        setCount1(function (preValue) {
            return preValue + 1;
        });
    }


    return (
        <div>

            <h1>Test</h1>
            <div onClick={() => setCount(count + 1)}>

                Test {count}

            </div>

            <div onClick={() => setCount1(count1 + 1)}>

                Test1 {count1}

            </div>

            <div onClick={incrementCount}>

                Test11 {count} -- {count1}

            </div>

        </div>

    );
}