export const REQUEST_POSTS = 'REQUEST_POSTS'
export const RECEIVE_POSTS = 'RECEIVE_POSTS'
export const SELECT_SUBREDDIT = 'SELECT_SUBREDDIT'
export const INVALIDATE_SUBREDDIT = 'INVALIDATE_SUBREDDIT'


import buildDispatchActions from '../redux-dispatch-action/buildDispatchActions';


export default buildDispatchActions({

    setStore(store) {
        this.$store = store;
    },

    selectSubreddit(subreddit) {
        return {
            type:SELECT_SUBREDDIT,
            payload:subreddit
        }
    },

    invalidateSubreddit(subreddit){
        return {
            type:INVALIDATE_SUBREDDIT,
            payload:subreddit
        }
    },

    fetchPostsIfNeeded(subreddit){
        var that = this;
        return {
            type:REQUEST_POSTS,
            payload:new Promise((resolve,reject) =>{
                var xxx = that.invalidateSubreddit(subreddit);
                setTimeout(function () {
                    resolve({name:23323})
                },100);
            })
        }
    },


})