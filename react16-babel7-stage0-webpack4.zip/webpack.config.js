const HtmlWebPackPlugin = require("html-webpack-plugin");
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const path = require('path');
const fs = require('fs');

const outputPath = path.resolve(__dirname, "dist");


module.exports = {
    entry: {
        'index': "./src/index.js"
    },
    output: {
        path: outputPath,
        publicPath: "./",
        filename: '[name].[hash].js',
        chunkFilename: "[name].[hash].js"
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: "babel-loader"
                }
            },
            {
                test: /\.html$/,
                use: [
                    {
                        loader: "html-loader"
                    }
                ]
            },
            {
                test: /\.less$/,
                use: ExtractTextPlugin.extract({
                    use: [
                        {
                            loader: 'css-loader'
                        },
                        {
                            loader: 'less-loader',
                            options: {
                                strictMath: true,
                                noIeCompat: true,
                            },
                        },
                    ]
                }),
            },
        ]
    },
    plugins: [
        new HtmlWebPackPlugin({
            template: path.join(__dirname, "./src/index.html"),
            filename: "index.html",
            chunks: ['index']
        }),
        new ExtractTextPlugin({
            filename: '[name].[hash].css'
        })
    ],
    devtool: 'cheap-source-map'
};